package InsertionSort;

public class Visao {
	
	public static void mostrarVetorOrdenado(int[] vetor) {
        for (int k = 0; k < vetor.length; k++) {
            System.out.println(vetor[k]);
        }
    }
}
