package InsertionSort;

public class Modelo {
	
	    public static void insertionSort(int[] vetor) {
	        for (int j = 1; j < vetor.length; j++) {
	            int key = vetor[j];
	            int i = j - 1;
	            while (i >= 0 && vetor[i] > key) {
	                vetor[i + 1] = vetor[i];
	                i--;
	            }
	            vetor[i + 1] = key;
	        }
	    }
	}
	

	
